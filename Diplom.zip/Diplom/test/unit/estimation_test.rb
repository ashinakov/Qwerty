require 'test_helper'

class EstimationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
