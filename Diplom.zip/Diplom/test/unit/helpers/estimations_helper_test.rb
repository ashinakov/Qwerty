require 'test_helper'

class EstimationsHelperTest < ActionView::TestCase
end
