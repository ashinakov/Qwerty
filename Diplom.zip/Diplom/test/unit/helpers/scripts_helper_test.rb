require 'test_helper'

class ScriptsHelperTest < ActionView::TestCase
end
