require 'test_helper'

class SubThemesHelperTest < ActionView::TestCase
end
