require 'test_helper'

class ScenariesHelperTest < ActionView::TestCase
end
