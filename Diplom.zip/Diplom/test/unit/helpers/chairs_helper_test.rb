require 'test_helper'

class ChairsHelperTest < ActionView::TestCase
end
