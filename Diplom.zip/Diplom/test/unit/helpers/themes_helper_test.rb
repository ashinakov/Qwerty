require 'test_helper'

class ThemesHelperTest < ActionView::TestCase
end
