require 'test_helper'

class WishesHelperTest < ActionView::TestCase
end
