require 'test_helper'

class FacultiesHelperTest < ActionView::TestCase
end
