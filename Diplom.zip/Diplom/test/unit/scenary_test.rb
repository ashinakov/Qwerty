require 'test_helper'

class ScenaryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
