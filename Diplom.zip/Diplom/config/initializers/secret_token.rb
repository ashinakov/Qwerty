# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Scenario::Application.config.secret_token = 'fd7c8b8b1112970e54f9bc8ec7f0e0f59b5e1d6dc99bfd44e78c76a1f23e7df8302270321a701e178b5c1ece355128ddda7b9d8f7566ea282010935a397739c8'
