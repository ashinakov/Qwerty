class Person < ActiveRecord::Base
  belongs_to :role
  validates :f_name, :presence => true, 
                         
                        :length => {:in=>1...30}
  
  validates :s_name, :presence => true,
                         
                         :length => {:in=>1...30}

  validates :l_name, :presence => true,
                          
                         :length => {:in=>1...30}

  validates :login, :presence => true,
                          
                         :length => {:in=>6...24}

  validates :password, :presence => true,
                          
                         :length => {:in=>8...24}
end
