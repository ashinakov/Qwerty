class Wish < ActiveRecord::Base
end
