class Faculty < ActiveRecord::Base
  has_many :groups
end
