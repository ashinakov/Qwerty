class Group < ActiveRecord::Base
  belongs_to :faculty
end
