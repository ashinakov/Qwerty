class Chair < ActiveRecord::Base
end
