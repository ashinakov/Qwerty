module ChairsHelper
end
