module FacultiesHelper
end
