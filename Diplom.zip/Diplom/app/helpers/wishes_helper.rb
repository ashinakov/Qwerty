module WishesHelper
end
