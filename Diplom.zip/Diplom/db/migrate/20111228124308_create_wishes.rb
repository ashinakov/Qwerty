class CreateWishes < ActiveRecord::Migration
  def change
    create_table :wishes do |t|
      t.integer :people_id
      t.integer :day
      t.integer :lesson

      t.timestamps
    end
  end
end
