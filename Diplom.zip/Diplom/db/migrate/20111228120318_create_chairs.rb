class CreateChairs < ActiveRecord::Migration
  def change
    create_table :chairs do |t|
      t.integer :number
      t.string :name
      t.integer :faculty_id

      t.timestamps
    end
  end
end
