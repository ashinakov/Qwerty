class CreateTerms < ActiveRecord::Migration
  def change
    create_table :terms do |t|
      t.string :title
      t.string :short_title
      t.boolean :current

      t.timestamps
    end
  end
end
