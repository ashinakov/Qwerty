class CreatePeople < ActiveRecord::Migration
  def change
    create_table :people do |t|
      t.string :f_name
      t.string :s_name
      t.string :l_name
      t.string :login
      t.string :password
      t.string :password_shif
      t.string :role_id

      t.timestamps
    end
  end
end
