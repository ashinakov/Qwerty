# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20111227100310) do

  create_table "discipline_groups", :force => true do |t|
    t.integer  "group_id"
    t.integer  "discipline_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "disciplines", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "estimations", :force => true do |t|
    t.integer  "theme_pct"
    t.integer  "question_pct"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "groups", :force => true do |t|
    t.string   "name"
    t.string   "year"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "questions", :force => true do |t|
    t.integer  "questions"
    t.integer  "answers"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "results", :force => true do |t|
    t.integer  "procents"
    t.integer  "themes"
    t.integer  "detalized"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "scenaries", :force => true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "scripts", :force => true do |t|
    t.integer  "order"
    t.string   "name"
    t.string   "redirect_page"
    t.integer  "time"
    t.integer  "blocked"
    t.integer  "test_id"
    t.integer  "scenary_id"
    t.integer  "results_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sub_themes", :force => true do |t|
    t.string   "name"
    t.integer  "start_num"
    t.integer  "end_num"
    t.integer  "theme_id"
    t.integer  "question_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tests", :force => true do |t|
    t.string   "name"
    t.integer  "necessary"
    t.integer  "block"
    t.integer  "num_try"
    t.integer  "period"
    t.string   "type"
    t.integer  "auth_type"
    t.integer  "w_key"
    t.integer  "ext_access"
    t.integer  "msiu_access"
    t.integer  "oder"
    t.integer  "disc_group_id"
    t.integer  "etimation_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "themes", :force => true do |t|
    t.string   "name"
    t.integer  "scenary_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "login",                     :limit => 40
    t.string   "name",                      :limit => 100, :default => ""
    t.string   "email",                     :limit => 100
    t.string   "crypted_password",          :limit => 40
    t.string   "salt",                      :limit => 40
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "remember_token",            :limit => 40
    t.datetime "remember_token_expires_at"
    t.string   "activation_code",           :limit => 40
    t.datetime "activated_at"
    t.string   "state",                                    :default => "passive"
    t.datetime "deleted_at"
  end

  add_index "users", ["login"], :name => "index_users_on_login", :unique => true

end
